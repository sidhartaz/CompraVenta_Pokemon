const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Inicializar app
const app = express();
const PORT = 3000;

// --- 1. MIDDLEWARE ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- 2. IMPORTAR MODELO ---
let User;
try {
    User = require('./models/User');
} catch (error) {
    console.error('❌ ERROR CRÍTICO: No se encuentra el archivo "models/User.js".');
    console.error('   Asegúrate de crear la carpeta "models" y el archivo "User.js".');
    process.exit(1);
}

// --- 3. CONEXIÓN A BASE DE DATOS ---
mongoose.connect('mongodb://127.0.0.1:27017/cardtrader')
    .then(() => console.log('✅ Base de Datos MongoDB conectada'))
    .catch((err) => {
        console.error('❌ ERROR DE CONEXIÓN A MONGO DB:');
        console.error('   Asegúrate de tener MongoDB instalado y corriendo.');
        console.error('   Detalle:', err.message);
    });

// --- 4. RUTAS DE API ---

// Registro
app.post('/api/register', async (req, res) => {
    console.log('📩 Registro:', req.body.email);
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) return res.status(400).json({ message: 'Faltan datos' });

    try {
        const userExists = await User.findOne({ email });
        if (userExists) return res.status(400).json({ message: 'El correo ya existe' });

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new User({ name, email, password: hashedPassword, role: role || 'cliente' });
        await newUser.save();
        
        console.log('✅ Usuario creado:', email);
        res.status(201).json({ message: 'Usuario registrado con éxito.' });

    } catch (error) {
        console.error('Error registro:', error);
        res.status(500).json({ message: 'Error del servidor' });
    }
});
app.get('/api/cards/:id', async (req, res) => {
    try {
        const cardId = req.params.id;

        const card = await Card.findOne({ id: cardId }).lean();
        if (!card) return res.json({ card: null, listings: [] });

        const listings = await Listing.find({ cardId })
            .populate('sellerId')
            .lean();

        const formattedListings = listings.map(lst => ({
            price: lst.price,
            condition: lst.condition,
            seller: lst.sellerId,
        }));

        res.json({
            card,
            listings: formattedListings
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
});

// Login
app.post('/api/login', async (req, res) => {
    console.log('🔑 Login:', req.body.email);
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: 'Credenciales inválidas' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: 'Credenciales inválidas' });

        res.json({
            message: 'Login exitoso',
            user: { id: user._id, name: user.name, email: user.email, role: user.role }
        });

    } catch (error) {
        console.error('Error login:', error);
        res.status(500).json({ message: 'Error del servidor' });
    }
});
// server.js o routes/cards.js
const Card = require('./models/Card');
const Listing = require('./models/Listing');
const Seller = require('./models/Seller');

app.get('/api/cards/search', async (req, res) => {
  try {
    const q = req.query.q || '';
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const skip = (page - 1) * limit;

    // Búsqueda por texto (nombre, set, etc.) y por nombre exacto parcial
    const query = q ? { $text: { $search: q } } : {};

    // Buscar cartas
    const cards = await Card.find(query, q ? { score: { $meta: "textScore" } } : {})
                          .sort(q ? { score: { $meta: "textScore" } } : { name: 1 })
                          .skip(skip).limit(limit).lean();

    // Para cada carta, leer listings aleatorios (puedes cambiar lógica)
    const results = await Promise.all(cards.map(async card => {
      const listings = await Listing.aggregate([
        { $match: { cardId: card.id || card._id.toString() } },
        { $sample: { size: 3 } }, // 3 listings aleatorios por carta
        { $lookup: { from: 'sellers', localField: 'sellerId', foreignField: '_id', as: 'seller' } },
        { $unwind: { path: '$seller', preserveNullAndEmptyArrays: true } }
      ]);
      return { card, listings };
    }));

    res.json({ ok:true, results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok:false, message: 'Error servidor' });
  }
});
app.get('/api/cards/autocomplete', async (req, res) => {
  const q = req.query.q || '';
  if(!q) return res.json([]);
  const items = await Card.find({ name: new RegExp('^' + q, 'i') }).limit(8).select('id name images').lean();
  res.json(items);
});
app.get('/api/cards/search', async (req, res) => {
    try {
        const query = req.query.q;

        if (!query) {
            return res.json({ results: [] });
        }

        // Buscar cartas que coincidan con el nombre
        const cards = await Card.find({
            name: { $regex: query, $options: 'i' }
        }).limit(20).lean();

        if (!cards.length) {
            return res.json({ results: [] });
        }

        // Para cada carta buscamos un vendedor/listing
        const results = [];

        for (const card of cards) {
            const listings = await Listing.find({ cardId: card.id })
                .populate('sellerId')
                .lean();

            const formattedListings = listings.map(lst => ({
                price: lst.price,
                condition: lst.condition,
                seller: lst.sellerId
            }));

            results.push({
                card,
                listings: formattedListings
            });
        }

        res.json({ results });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
});
app.get('/api/cards/:id', async (req, res) => {
    try {
        const cardId = req.params.id;

        const card = await Card.findOne({ id: cardId }).lean();
        if (!card) {
            return res.json({ card: null, listings: [] });
        }

        const listings = await Listing.find({ cardId })
            .populate('sellerId')
            .lean();

        const formattedListings = listings.map(lst => ({
            price: lst.price,
            condition: lst.condition,
            seller: lst.sellerId
        }));

        res.json({
            card,
            listings: formattedListings
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error interno del servidor" });
    }
});


// --- 5. RUTA FALLBACK (CORREGIDA) ---
// CAMBIO IMPORTANTE: Usamos una expresión regular /(.*)/ en vez de '*'
app.get(/(.*)/, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- 6. INICIAR ---
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});